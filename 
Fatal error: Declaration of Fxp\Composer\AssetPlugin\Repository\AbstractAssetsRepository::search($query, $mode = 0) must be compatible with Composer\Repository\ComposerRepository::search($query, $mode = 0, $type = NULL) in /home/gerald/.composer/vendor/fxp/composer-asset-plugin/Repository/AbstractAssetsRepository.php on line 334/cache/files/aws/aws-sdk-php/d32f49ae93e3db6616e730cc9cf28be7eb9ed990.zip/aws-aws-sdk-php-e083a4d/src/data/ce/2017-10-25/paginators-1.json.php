<?php
// This file was auto-generated from sdk-root/src/data/ce/2017-10-25/paginators-1.json
return [ 'pagination' => [],];
