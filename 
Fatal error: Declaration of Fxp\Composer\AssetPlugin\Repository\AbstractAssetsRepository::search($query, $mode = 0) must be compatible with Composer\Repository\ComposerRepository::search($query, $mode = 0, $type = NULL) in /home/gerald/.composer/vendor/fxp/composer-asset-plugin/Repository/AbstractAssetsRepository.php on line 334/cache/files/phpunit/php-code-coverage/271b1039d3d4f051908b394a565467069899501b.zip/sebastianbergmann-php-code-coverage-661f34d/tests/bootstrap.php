<?php
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/TestCase.php';

define('TEST_FILES_PATH', __DIR__ . '/_files/');
