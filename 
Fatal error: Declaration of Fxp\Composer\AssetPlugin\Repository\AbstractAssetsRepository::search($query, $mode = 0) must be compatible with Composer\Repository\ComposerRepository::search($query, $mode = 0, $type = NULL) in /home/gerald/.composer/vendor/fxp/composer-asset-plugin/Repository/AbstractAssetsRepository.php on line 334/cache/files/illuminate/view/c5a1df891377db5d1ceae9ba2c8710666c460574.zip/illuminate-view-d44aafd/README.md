# Illuminate View

[![Build Status](https://secure.travis-ci.org/illuminate/view.png)](http://travis-ci.org/illuminate/view)